import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'controllers/obd_controller.dart';
import 'screens/device_list_screen.dart';

void main() {
  runApp(const Obd2ReaderApp());
}

class Obd2ReaderApp extends StatelessWidget {
  const Obd2ReaderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ObdController(),
      child: MaterialApp(
        title: 'OBD2 Reader',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorSchemeSeed: Colors.teal,
          useMaterial3: true,
        ),
        home: const DeviceListScreen(),
      ),
    );
  }
}
