import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/obd_sample.dart';

/// Menulis log sample OBD2 yang sudah terkumpul ke file JSON/CSV di
/// penyimpanan aplikasi, lalu membukanya lewat share sheet Android supaya
/// mudah dipindahkan ke aplikasi lain (Drive, email, Python di laptop, dst)
/// untuk diolah lebih lanjut.
class DataExporter {
  static Future<File> exportJson(List<ObdSample> samples) async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File(
      '${dir.path}/obd2_log_${DateTime.now().millisecondsSinceEpoch}.json',
    );
    final jsonList = samples.map((s) => s.toJson()).toList();
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(jsonList));
    return file;
  }

  static Future<File> exportCsv(List<ObdSample> samples) async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File(
      '${dir.path}/obd2_log_${DateTime.now().millisecondsSinceEpoch}.csv',
    );
    final buffer = StringBuffer()
      ..writeln('timestamp,pid,name,raw_hex,decoded_value,unit');
    for (final s in samples) {
      buffer.writeln(s.toCsvRow());
    }
    await file.writeAsString(buffer.toString());
    return file;
  }

  static Future<void> shareFile(File file) async {
    await Share.shareXFiles([XFile(file.path)]);
  }
}
