import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_blue_classic/flutter_blue_classic.dart';

import 'obd_parser.dart';

/// Lapisan komunikasi mentah ke dongle ELM327 lewat Bluetooth Classic (SPP).
///
/// Tanggung jawabnya cuma tiga: buka/tutup koneksi, mengirim satu command
/// dan menunggu satu balasan penuh (sampai ketemu prompt '>'), dan
/// menyediakan helper inisialisasi ELM327 + deteksi PID yang didukung mobil.
/// Semua logic decode nilai fisik (RPM, suhu, dst) ada di layer lain
/// (obd_pid.dart) supaya kelas ini tetap fokus ke urusan transport saja.
class ObdBluetoothService {
  final FlutterBlueClassic _blueClassic = FlutterBlueClassic();

  BluetoothConnection? _connection;
  StreamSubscription<Uint8List>? _inputSub;
  final StreamController<String> _responseController =
      StreamController<String>.broadcast();
  final StringBuffer _rxBuffer = StringBuffer();

  // Antrian sederhana supaya command dikirim satu-satu secara berurutan.
  // ELM327 itu half-duplex: kalau dua command dikirim bersamaan, responsnya
  // akan bercampur dan tidak bisa dipisahkan lagi.
  Future<void> _commandQueue = Future.value();

  Stream<String> get rawResponses => _responseController.stream;

  bool get isConnected => _connection?.isConnected ?? false;

  Future<bool> get isBluetoothSupported => _blueClassic.isSupported;
  Future<bool> get isBluetoothEnabled => _blueClassic.isEnabled;

  Future<List<BluetoothDevice>> getBondedDevices() async {
    final devices = await _blueClassic.bondedDevices;
    return devices ?? const <BluetoothDevice>[];
  }

  Future<void> connect(BluetoothDevice device) async {
    final connection = await _blueClassic.connect(device.address);
    if (connection == null) {
      throw Exception(
        'Gagal terhubung ke ${device.name ?? device.address}. '
        'Pastikan dongle sudah di-pairing di Pengaturan Bluetooth Android '
        'dan tidak sedang dipakai aplikasi lain.',
      );
    }
    _connection = connection;
    _rxBuffer.clear();
    _inputSub = connection.input?.listen(
      _onDataReceived,
      onError: (_) {},
      onDone: () {},
    );
  }

  void _onDataReceived(Uint8List data) {
    _rxBuffer.write(utf8.decode(data, allowMalformed: true));
    final content = _rxBuffer.toString();

    // ELM327 selalu mengakhiri satu balasan penuh dengan karakter prompt '>'.
    // Selama belum ada '>', anggap datanya belum lengkap dan tunggu chunk berikutnya.
    if (content.contains('>')) {
      final parts = content.split('>');
      // Elemen terakhir adalah sisa buffer yang belum ditutup prompt.
      for (var i = 0; i < parts.length - 1; i++) {
        _responseController.add(parts[i]);
      }
      _rxBuffer
        ..clear()
        ..write(parts.last);
    }
  }

  /// Kirim satu command teks (tanpa '\r', akan ditambahkan otomatis) dan
  /// tunggu satu balasan penuh dari ELM327. Command lain yang dipanggil
  /// sebelum ini selesai akan otomatis diantre, bukan dikirim bersamaan.
  Future<String> sendCommand(
    String command, {
    Duration timeout = const Duration(seconds: 3),
  }) {
    final result = _commandQueue.then((_) => _sendCommandImpl(command, timeout));
    // Apapun hasil command ini (sukses/gagal), antrean harus tetap lanjut.
    _commandQueue = result.then((_) {}, onError: (_) {});
    return result;
  }

  Future<String> _sendCommandImpl(String command, Duration timeout) async {
    final connection = _connection;
    if (connection == null || !connection.isConnected) {
      throw StateError('Tidak ada koneksi Bluetooth aktif ke dongle OBD2.');
    }

    final completer = Completer<String>();
    late final StreamSubscription<String> sub;
    sub = rawResponses.listen((resp) {
      if (!completer.isCompleted) {
        completer.complete(resp);
      }
    });

    try {
      connection.output.add(utf8.encode('$command\r'));
      return await completer.future.timeout(
        timeout,
        onTimeout: () {
          throw TimeoutException(
            'Timeout menunggu respons untuk perintah "$command".',
          );
        },
      );
    } finally {
      await sub.cancel();
    }
  }

  /// Urutan inisialisasi standar ELM327: reset, matikan echo, matikan
  /// line-feed & spasi tambahan, matikan header CAN, lalu biarkan ELM327
  /// pilih sendiri protokol OBD yang cocok dengan mobil (auto-protocol).
  Future<void> initializeElm327() async {
    const initCommands = ['ATZ', 'ATE0', 'ATL0', 'ATS0', 'ATH0', 'ATSP0'];
    for (final cmd in initCommands) {
      try {
        await sendCommand(cmd, timeout: const Duration(seconds: 5));
      } catch (_) {
        // Satu command init gagal/timeout tidak menghentikan seluruh proses;
        // beberapa klon ELM327 memang lambat/aneh merespons command tertentu.
      }
    }
  }

  /// Query PID 00/20/40/60/80/A0/C0 (Mode 01) untuk mendapatkan bitmask PID
  /// apa saja yang didukung mobil, sesuai konvensi SAE J1979. Setiap query
  /// mengembalikan 4 byte = 32 bit, tiap bit mewakili satu PID berikutnya.
  Future<Set<String>> discoverSupportedPids() async {
    final supported = <String>{};
    const bitmaskQueries = ['00', '20', '40', '60', '80', 'A0', 'C0'];

    for (final query in bitmaskQueries) {
      String response;
      try {
        response = await sendCommand('01$query', timeout: const Duration(seconds: 3));
      } catch (_) {
        break;
      }

      final bytes = ObdParser.extractDataBytes(
        response,
        expectedMode: '41',
        expectedPid: query,
      );
      if (bytes == null || bytes.length < 4) break;

      final bitmask =
          (bytes[0] << 24) | (bytes[1] << 16) | (bytes[2] << 8) | bytes[3];
      final basePid = int.parse(query, radix: 16);

      var hasNextRange = false;
      for (var i = 0; i < 32; i++) {
        if ((bitmask & (0x80000000 >> i)) != 0) {
          final pidNum = basePid + i + 1;
          final pidHex = pidNum.toRadixString(16).padLeft(2, '0').toUpperCase();
          supported.add(pidHex);
          // Bit terakhir (i == 31) menandakan PID grup berikutnya (mis. 0x20,
          // 0x40, dst) juga didukung, artinya masih ada rentang PID lanjutan.
          if (i == 31) hasNextRange = true;
        }
      }
      if (!hasNextRange) break;
    }
    return supported;
  }

  Future<void> disconnect() async {
    await _inputSub?.cancel();
    _inputSub = null;
    final connection = _connection;
    _connection = null;
    if (connection != null) {
      try {
        await connection.finish();
      } catch (_) {
        connection.dispose();
      }
    }
  }

  void dispose() {
    _inputSub?.cancel();
    _connection?.dispose();
    _responseController.close();
  }
}
