import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/obd_controller.dart';
import 'raw_terminal_screen.dart';

/// Layar utama: menampilkan nilai terbaru tiap PID yang berhasil didekode,
/// plus akses ke terminal mentah dan export data.
class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  String _stateLabel(ObdConnectionState state) {
    switch (state) {
      case ObdConnectionState.disconnected:
        return 'Terputus';
      case ObdConnectionState.connecting:
        return 'Menghubungkan...';
      case ObdConnectionState.initializing:
        return 'Inisialisasi ELM327...';
      case ObdConnectionState.discoveringPids:
        return 'Mendeteksi PID yang didukung...';
      case ObdConnectionState.ready:
        return 'Siap';
      case ObdConnectionState.polling:
        return 'Membaca data...';
      case ObdConnectionState.error:
        return 'Error';
    }
  }

  Future<void> _handleExport(BuildContext context, String type) async {
    final controller = context.read<ObdController>();
    final messenger = ScaffoldMessenger.of(context);
    try {
      if (type == 'json') {
        await controller.exportAndShareJson();
      } else {
        await controller.exportAndShareCsv();
      }
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Gagal export: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ObdController>(
      builder: (context, controller, _) {
        final isPolling = controller.state == ObdConnectionState.polling;
        final samples = controller.latestByPid.values.toList()
          ..sort((a, b) => a.pid.compareTo(b.pid));

        return Scaffold(
          appBar: AppBar(
            title: Text(controller.connectedDevice?.name ?? 'OBD2 Reader'),
            actions: [
              IconButton(
                icon: Icon(isPolling ? Icons.pause : Icons.play_arrow),
                tooltip: isPolling ? 'Jeda polling' : 'Lanjutkan polling',
                onPressed: () {
                  if (isPolling) {
                    controller.stopPolling();
                  } else {
                    controller.resumePolling();
                  }
                },
              ),
              PopupMenuButton<String>(
                onSelected: (value) {
                  switch (value) {
                    case 'raw':
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const RawTerminalScreen()),
                      );
                      break;
                    case 'export_json':
                      _handleExport(context, 'json');
                      break;
                    case 'export_csv':
                      _handleExport(context, 'csv');
                      break;
                    case 'disconnect':
                      controller.disconnect();
                      Navigator.of(context).popUntil((r) => r.isFirst);
                      break;
                  }
                },
                itemBuilder: (context) => const [
                  PopupMenuItem(
                    value: 'raw',
                    child: Text('Terminal mentah / PID kustom'),
                  ),
                  PopupMenuItem(value: 'export_json', child: Text('Export JSON')),
                  PopupMenuItem(value: 'export_csv', child: Text('Export CSV')),
                  PopupMenuItem(value: 'disconnect', child: Text('Putuskan koneksi')),
                ],
              ),
            ],
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(
                  children: [
                    Expanded(child: Text('Status: ${_stateLabel(controller.state)}')),
                    Text(
                      '${controller.supportedPids.length} PID · ${controller.log.length} sampel',
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ],
                ),
              ),
              if (controller.state == ObdConnectionState.error)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Text(
                    controller.errorMessage ?? 'Terjadi kesalahan',
                    style: const TextStyle(color: Colors.red),
                  ),
                ),
              Expanded(
                child: samples.isEmpty
                    ? const Center(child: Text('Menunggu data pertama...'))
                    : GridView.builder(
                        padding: const EdgeInsets.all(8),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          childAspectRatio: 1.5,
                          crossAxisSpacing: 8,
                          mainAxisSpacing: 8,
                        ),
                        itemCount: samples.length,
                        itemBuilder: (context, index) {
                          final sample = samples[index];
                          return Card(
                            child: Padding(
                              padding: const EdgeInsets.all(12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    sample.name,
                                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    sample.decodedValue != null
                                        ? '${sample.decodedValue!.toStringAsFixed(1)} ${sample.unit}'
                                        : '-',
                                    style: const TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    'PID ${sample.pid} · raw: ${sample.rawHex}',
                                    style: const TextStyle(fontSize: 10, color: Colors.grey),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}
