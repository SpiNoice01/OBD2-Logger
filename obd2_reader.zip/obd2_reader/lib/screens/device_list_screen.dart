import 'package:flutter/material.dart';
import 'package:flutter_blue_classic/flutter_blue_classic.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

import '../controllers/obd_controller.dart';
import 'dashboard_screen.dart';

/// Layar awal: minta izin Bluetooth runtime, lalu tampilkan daftar
/// perangkat Bluetooth yang SUDAH di-pairing (bonded) di Android.
///
/// Catatan: dongle OBD2 classic (SPP) harus dipasangkan dulu lewat
/// Pengaturan Bluetooth bawaan Android (biasanya minta PIN 1234 atau 0000)
/// sebelum bisa muncul & dipilih di sini.
class DeviceListScreen extends StatefulWidget {
  const DeviceListScreen({super.key});

  @override
  State<DeviceListScreen> createState() => _DeviceListScreenState();
}

class _DeviceListScreenState extends State<DeviceListScreen> {
  List<BluetoothDevice> _devices = [];
  bool _loading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _init());
  }

  Future<void> _init() async {
    await _requestPermissions();
    await _refreshDevices();
  }

  Future<void> _requestPermissions() async {
    await [
      Permission.bluetoothConnect,
      Permission.bluetoothScan,
    ].request();
  }

  Future<void> _refreshDevices() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final controller = context.read<ObdController>();
      final devices = await controller.loadBondedDevices();
      if (!mounted) return;
      setState(() => _devices = devices);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'Gagal mengambil daftar perangkat: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _connect(BluetoothDevice device) {
    final controller = context.read<ObdController>();
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const DashboardScreen()),
    );
    controller.connectAndInitialize(device);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pilih Dongle OBD2'),
        actions: [
          IconButton(
            onPressed: _loading ? null : _refreshDevices,
            icon: const Icon(Icons.refresh),
            tooltip: 'Muat ulang daftar perangkat',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refreshDevices,
        child: ListView(
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Pastikan dongle OBD2 sudah dipasangkan (paired) lewat '
                'Pengaturan Bluetooth Android terlebih dahulu, baru pilih '
                'perangkatnya di bawah ini.',
              ),
            ),
            if (_loading) const LinearProgressIndicator(),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.all(16),
                child: Text(_error!, style: const TextStyle(color: Colors.red)),
              ),
            if (!_loading && _devices.isEmpty && _error == null)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('Belum ada perangkat Bluetooth yang dipasangkan.'),
              ),
            for (final device in _devices)
              ListTile(
                leading: const Icon(Icons.bluetooth),
                title: Text(device.name ?? '(Tanpa nama)'),
                subtitle: Text(device.address),
                onTap: () => _connect(device),
              ),
          ],
        ),
      ),
    );
  }
}
